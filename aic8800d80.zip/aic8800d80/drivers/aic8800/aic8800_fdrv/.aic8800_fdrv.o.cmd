savedcmd_aic8800_fdrv/aic8800_fdrv.o := aarch64-linux-gnu-ld -EL  -maarch64elf -z noexecstack --no-warn-rwx-segments   -r -o aic8800_fdrv/aic8800_fdrv.o @aic8800_fdrv/aic8800_fdrv.mod 
