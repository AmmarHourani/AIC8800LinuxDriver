savedcmd_aic_load_fw/aic_load_fw.o := aarch64-linux-gnu-ld -EL  -maarch64elf -z noexecstack --no-warn-rwx-segments   -r -o aic_load_fw/aic_load_fw.o @aic_load_fw/aic_load_fw.mod 
